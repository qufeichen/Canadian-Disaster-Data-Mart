Clustering Analysis:
- 990 instances
- number of clusters = root(990/2) ~= 22
- ran SimpleKMeans with 22 clusters

Results on entire data set:
- simplekmeans.txt
- simplekmeans.png (visualization)

Results on data with the summary removed:
- simplekmeans_nosummary.txt
- simplekmeans_nosummary.png

also tried to add clusters as an attribute
(see cluster_as_attribute.png)
