Drilled down to the lowest possible hierarchy in order to return a proper accuracy score.
