-- queries to export tables
Copy costs To '/Users/qufeichen/Documents/Repos/CSI4142-Project/costs.csv' With CSV DELIMITER ',' HEADER;
Copy date To '/Users/qufeichen/Documents/Repos/CSI4142-Project/date.csv' With CSV DELIMITER ',' HEADER;
Copy disaster To '/Users/qufeichen/Documents/Repos/CSI4142-Project/disaster.csv' With CSV DELIMITER ',' HEADER;
Copy location To '/Users/qufeichen/Documents/Repos/CSI4142-Project/location.csv' With CSV DELIMITER ',' HEADER;
Copy summary To '/Users/qufeichen/Documents/Repos/CSI4142-Project/summary.csv' With CSV DELIMITER ',' HEADER;
Copy population_statistics To '/Users/qufeichen/Documents/Repos/CSI4142-Project/population_statistics.csv' With CSV DELIMITER ',' HEADER;
Copy weather_info To '/Users/qufeichen/Documents/Repos/CSI4142-Project/weather_info.csv' With CSV DELIMITER ',' HEADER;
Copy fact_table To '/Users/qufeichen/Documents/Repos/CSI4142-Project/fact_table.csv' With CSV DELIMITER ',' HEADER;
